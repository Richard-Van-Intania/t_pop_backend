--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE t_pop_app;
--
-- Name: t_pop_app; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE t_pop_app WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE t_pop_app OWNER TO postgres;

\unrestrict (null)
\connect t_pop_app
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: packages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packages (
    packages_uuid uuid DEFAULT uuidv7() NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    price double precision NOT NULL,
    duration_days integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    benefits text NOT NULL
);


ALTER TABLE public.packages OWNER TO postgres;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subscriptions (
    subscriptions_uuid uuid DEFAULT uuidv7() NOT NULL,
    users_uuid uuid NOT NULL,
    packages_uuid uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expired_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    payment_method text NOT NULL
);


ALTER TABLE public.subscriptions OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    users_uuid uuid DEFAULT uuidv7() NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    display_name text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: packages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.packages (packages_uuid, title, description, price, duration_days, created_at, updated_at, is_active, benefits) FROM stdin;
\.
COPY public.packages (packages_uuid, title, description, price, duration_days, created_at, updated_at, is_active, benefits) FROM '$$PATH$$/3836.dat';

--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subscriptions (subscriptions_uuid, users_uuid, packages_uuid, created_at, expired_at, is_active, payment_method) FROM stdin;
\.
COPY public.subscriptions (subscriptions_uuid, users_uuid, packages_uuid, created_at, expired_at, is_active, payment_method) FROM '$$PATH$$/3837.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (users_uuid, email, password, display_name, created_at, updated_at) FROM stdin;
\.
COPY public.users (users_uuid, email, password, display_name, created_at, updated_at) FROM '$$PATH$$/3835.dat';

--
-- Name: packages packages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_pkey PRIMARY KEY (packages_uuid);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (subscriptions_uuid);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (users_uuid);


--
-- Name: subscriptions subscriptions_packages_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_packages_uuid_fkey FOREIGN KEY (packages_uuid) REFERENCES public.packages(packages_uuid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_users_uuid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_users_uuid_fkey FOREIGN KEY (users_uuid) REFERENCES public.users(users_uuid) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

